#ifndef ALERT_H
#define ALERT_H

void triggerifCritical(float temperature, float humidity);
void triggerAlert(int sig);

#endif


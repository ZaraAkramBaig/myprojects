#ifndef API_INTERACTION_H
#define API_INTERACTION_H

void retrieve_weather_data(const char*city);

#endif
#!/bin/bash
# run_system.sh
./weather_update
